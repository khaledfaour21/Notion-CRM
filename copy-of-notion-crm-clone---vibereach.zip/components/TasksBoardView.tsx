import React from 'react';
import { Task, TaskStatus, Lead, Priority } from '../types';
import { TASK_STATUS_CONFIG } from '../constants';
import { PlusIcon, FileTextIcon } from './icons';

interface TasksBoardViewProps {
  tasks: Task[];
  leads: Lead[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

const TaskCard: React.FC<{ task: Task; lead: Lead | undefined }> = ({ task, lead }) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('taskId', task.id.toString());
  };

  const priorityColors: Record<Priority, string> = {
    [Priority.Low]: 'bg-green-600/30 text-green-300',
    [Priority.Medium]: 'bg-yellow-600/30 text-yellow-300',
    [Priority.High]: 'bg-red-600/30 text-red-300',
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="bg-[#2F2F2F] p-3 rounded-md border border-gray-700 cursor-grab active:cursor-grabbing shadow-sm"
    >
      <p className="font-medium text-white">{task.title}</p>
      {lead && (
        <div className="flex items-center space-x-2 text-sm text-gray-400 pt-1">
          <FileTextIcon className="w-3 h-3"/>
          <span>{lead.name}</span>
        </div>
      )}
      {task.priority && (
        <div className="pt-2">
          <span className={`px-2 py-0.5 rounded text-xs font-medium ${priorityColors[task.priority]}`}>
              {task.priority}
          </span>
        </div>
      )}
    </div>
  );
};

const TasksBoardView: React.FC<TasksBoardViewProps> = ({ tasks, leads, setTasks }) => {
    const handleDrop = (newStatus: TaskStatus, e: React.DragEvent<HTMLDivElement>) => {
        const taskId = parseInt(e.dataTransfer.getData('taskId'), 10);
        if (!taskId) return;

        setTasks(prevTasks =>
            prevTasks.map(task =>
                task.id === taskId ? { ...task, status: newStatus } : task
            )
        );
        e.currentTarget.classList.remove('bg-gray-700/50');
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.currentTarget.classList.add('bg-gray-700/50');
    }
    
    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.currentTarget.classList.remove('bg-gray-700/50');
    }

    const getLeadById = (id: number | null): Lead | undefined => {
        if (id === null) return undefined;
        return leads.find(lead => lead.id === id);
    }

    return (
        <div className="flex space-x-4 overflow-x-auto pb-4 h-full">
            {(Object.values(TaskStatus) as TaskStatus[]).map(status => {
                const config = TASK_STATUS_CONFIG[status];
                const filteredTasks = tasks.filter(t => t.status === status);
                
                return (
                    <div
                        key={status}
                        className="flex-shrink-0 w-72 flex flex-col"
                    >
                        <div className="flex items-center space-x-2 p-2">
                            {/* FIX: Removed 'as React.ReactElement' cast. The type of icon is now correctly defined in constants.tsx. */}
                            {React.cloneElement(config.icon, { className: `w-4 h-4 ${config.textColor}`})}
                            <span className={`font-medium ${config.textColor}`}>{status}</span>
                            <span className="text-sm text-gray-400">{filteredTasks.length}</span>
                        </div>
                        <div 
                            className={`p-2 space-y-3 rounded-lg ${config.color} flex-grow transition-colors`}
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onDrop={(e) => handleDrop(status, e)}
                        >
                            {filteredTasks.map(task => (
                                <TaskCard key={task.id} task={task} lead={getLeadById(task.leadId)} />
                            ))}
                            <button className="flex items-center space-x-2 p-2 w-full rounded text-gray-400 hover:bg-gray-600/50 transition-colors">
                                <PlusIcon className="w-4 h-4" />
                                <span>New page</span>
                            </button>
                        </div>
                    </div>
                )
            })}
        </div>
    );
}

export default TasksBoardView;