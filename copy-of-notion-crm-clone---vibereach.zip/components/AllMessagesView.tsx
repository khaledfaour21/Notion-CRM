import React, { useState } from 'react';
import { Lead, ContactChannel, Direction, MessageRow } from '../types';
import {
  FileTextIcon,
  LeadsIcon,
  CalendarIcon,
  MessageSquareIcon,
  PlusIcon,
  InfoIcon,
  CircleIcon,
} from './icons';

const initialMessages: MessageRow[] = [
  { id: 1, title: 'hi', leadName: 'omar', date: '', direction: Direction.Sent, channel: ContactChannel.LinkedIn, content: '“I want you to design a Notion v' },
  { id: 2, title: '', leadName: 'omar', date: '', direction: null, channel: null, content: '' },
];

interface AllMessagesViewProps {
  leads: Lead[];
  onSelectMessage: (message: MessageRow) => void;
}

const AllMessagesView: React.FC<AllMessagesViewProps> = ({ leads, onSelectMessage }) => {
  const [messages, setMessages] = useState<MessageRow[]>(initialMessages);

  const addRow = () => {
    const newRow: MessageRow = {
      id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
      title: '',
      leadName: '',
      date: '',
      direction: null,
      channel: null,
      content: '',
    };
    setMessages([...messages, newRow]);
  };

  const columns = [
    { id: 'title', title: 'Message', icon: <FileTextIcon className="w-4 h-4" /> },
    { id: 'leadName', title: 'Lead', icon: <LeadsIcon className="w-4 h-4" /> },
    { id: 'date', title: 'Date', icon: <CalendarIcon className="w-4 h-4" /> },
    { id: 'direction', title: 'Direction', icon: <CircleIcon className="w-4 h-4" /> },
    { id: 'channel', title: 'Channel', icon: <MessageSquareIcon className="w-4 h-4" /> },
    { id: 'content', title: 'Message Content', icon: <FileTextIcon className="w-4 h-4" /> },
  ];

  const directionColors: Record<Direction, string> = {
    [Direction.Sent]: 'bg-[#433459] text-[#A686D7]',
    [Direction.Received]: 'bg-blue-600/30 text-blue-300',
  };

  const channelColors: Record<ContactChannel, string> = {
    [ContactChannel.LinkedIn]: 'bg-[#59344F] text-[#D786AB]',
    [ContactChannel.Email]: 'bg-green-600/30 text-green-300',
    [ContactChannel.Phone]: 'bg-yellow-600/30 text-yellow-300',
    [ContactChannel.Other]: 'bg-gray-600/30 text-gray-300',
  };

  const gridTemplateColumns = `minmax(150px, 1fr) minmax(150px, 1fr) 150px 120px 150px minmax(300px, 2fr)`;

  return (
    <div className="text-sm">
      <div className="border border-gray-800 rounded-lg overflow-x-auto">
        <div className="min-w-max">
          {/* Table Header */}
          <div className="grid bg-[#202020] border-b border-gray-700" style={{ gridTemplateColumns }}>
            {columns.map(col => (
              <div key={col.id} className="flex items-center space-x-2 p-2.5 font-medium text-gray-400 border-r border-gray-700 last:border-r-0">
                {col.icon}
                <span>{col.title}</span>
                <InfoIcon className="w-3 h-3 text-gray-500" />
              </div>
            ))}
          </div>

          {/* Table Body */}
          <div>
            {messages.map(message => (
              <div
                key={message.id}
                className="grid items-center border-b border-gray-800 last:border-b-0 hover:bg-gray-800/20 cursor-pointer"
                style={{ gridTemplateColumns }}
                onClick={() => onSelectMessage(message)}
              >
                <div className="p-2.5 border-r border-gray-700 h-full flex items-center space-x-2">
                  <FileTextIcon className="w-4 h-4 text-gray-500 shrink-0" />
                  <span>{message.title}</span>
                </div>
                <div className="p-2.5 border-r border-gray-700 h-full flex items-center space-x-2">
                  <FileTextIcon className="w-4 h-4 text-gray-500 shrink-0" />
                  <span>{message.leadName}</span>
                </div>
                <div className="p-2.5 border-r border-gray-700 h-full">{message.date}</div>
                <div className="p-2.5 border-r border-gray-700 h-full">
                  {message.direction && (
                    <span className={`px-2 py-0.5 rounded-md text-xs font-medium ${directionColors[message.direction]}`}>
                      {message.direction}
                    </span>
                  )}
                </div>
                <div className="p-2.5 border-r border-gray-700 h-full">
                  {message.channel && (
                    <span className={`px-2 py-0.5 rounded-md text-xs font-medium ${channelColors[message.channel]}`}>
                      {message.channel}
                    </span>
                  )}
                </div>
                <div 
                  className="p-2.5 border-r-0 h-full text-gray-400 truncate"
                >
                  {message.content}
                </div>
              </div>
            ))}
          </div>

          {/* Table Footer */}
          <div
            onClick={addRow}
            className="flex items-center space-x-2 p-2.5 cursor-pointer text-gray-400 hover:bg-gray-800/40"
          >
            <PlusIcon className="w-4 h-4" />
            <span>New page</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllMessagesView;