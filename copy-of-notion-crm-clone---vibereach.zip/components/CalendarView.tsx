import React, { useState, useMemo } from 'react';
import { Lead } from '../types';
import { PlusIcon, CalendarIcon, ChevronLeftIcon, ChevronRightIcon } from './icons';

interface CalendarViewProps {
    leads: Lead[];
}

const CalendarView: React.FC<CalendarViewProps> = ({ leads }) => {
    const [currentDate, setCurrentDate] = useState(new Date('2025-10-01T12:00:00Z'));

    const changeMonth = (amount: number) => {
        setCurrentDate(prev => {
            const newDate = new Date(prev);
            newDate.setMonth(newDate.getMonth() + amount);
            return newDate;
        });
    };

    const calendarGrid = useMemo(() => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        const grid: (Date | null)[] = [];

        // Add days from previous month
        const prevMonthDays = new Date(year, month, 0).getDate();
        for (let i = 0; i < firstDayOfMonth; i++) {
            grid.push(new Date(year, month - 1, prevMonthDays - firstDayOfMonth + i + 1));
        }

        // Add days from current month
        for (let i = 1; i <= daysInMonth; i++) {
            grid.push(new Date(year, month, i));
        }

        // Add days from next month
        const remainingCells = 42 - grid.length; // 6 weeks * 7 days
        for (let i = 1; i <= remainingCells; i++) {
            grid.push(new Date(year, month + 1, i));
        }
        
        return grid;
    }, [currentDate]);

    const eventsByDate = useMemo(() => {
        const events: { [key: string]: Lead[] } = {};
        leads.forEach(lead => {
            if (lead.lastContactDate) {
                const dateKey = new Date(lead.lastContactDate).toISOString().split('T')[0];
                if (!events[dateKey]) {
                    events[dateKey] = [];
                }
                events[dateKey].push(lead);
            }
        });
        return events;
    }, [leads]);


    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    return (
        <div>
            {/* Calendar Toolbar */}
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">
                    {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                </h3>
                <div className="flex items-center space-x-2 text-sm text-gray-300">
                    <button className="px-3 py-1 rounded hover:bg-gray-800 transition-colors">
                        No date (3)
                    </button>
                    <div className="border-l border-gray-700 h-5"></div>
                    <button className="flex items-center space-x-2 px-3 py-1 rounded bg-[#2F2F2F] hover:bg-gray-700 transition-colors">
                        <CalendarIcon className="w-4 h-4" />
                        <span>Manage in Calendar</span>
                    </button>
                    <div className="flex items-center border border-gray-700 rounded-md">
                        <button onClick={() => changeMonth(-1)} className="p-1.5 hover:bg-gray-800 rounded-l-md transition-colors border-r border-gray-700">
                            <ChevronLeftIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => setCurrentDate(new Date())} className="px-3 py-1 hover:bg-gray-800 transition-colors border-r border-gray-700">
                            Today
                        </button>
                        <button onClick={() => changeMonth(1)} className="p-1.5 hover:bg-gray-800 rounded-r-md transition-colors">
                            <ChevronRightIcon className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>

            {/* Calendar Grid */}
            <div className="border-t border-l border-gray-800">
                <div className="grid grid-cols-7">
                    {weekdays.map(day => (
                        <div key={day} className="text-center text-xs font-medium text-gray-400 py-2 border-r border-b border-gray-800 bg-[#202020]">
                            {day}
                        </div>
                    ))}
                </div>
                <div className="grid grid-cols-7 grid-rows-6 h-[calc(100vh-250px)]">
                    {calendarGrid.map((date, index) => {
                        if (!date) return <div key={index}></div>;
                        const isCurrentMonth = date.getMonth() === currentDate.getMonth();
                        const dateKey = date.toISOString().split('T')[0];
                        const dayEvents = eventsByDate[dateKey] || [];
                        
                        return (
                            <div key={index} className="relative p-2 border-r border-b border-gray-800 group overflow-y-auto">
                                <span className={`text-sm ${isCurrentMonth ? 'text-gray-300' : 'text-gray-600'}`}>{date.getDate()}</span>
                                <button className="absolute top-2 right-2 p-1 bg-[#2F2F2F] rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                                    <PlusIcon className="w-3 h-3 text-gray-400"/>
                                </button>
                                <div className="mt-2 space-y-1">
                                    {dayEvents.map(event => (
                                        <div key={event.id} className="bg-[#2F2F2F] p-1.5 rounded-md text-xs text-white flex items-center justify-between">
                                            <span className="truncate">{event.name}</span>
                                            <span className="flex-shrink-0 ml-1 w-4 h-4 bg-red-600 text-white text-[10px] flex items-center justify-center rounded-full">1</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    );
};

export default CalendarView;
