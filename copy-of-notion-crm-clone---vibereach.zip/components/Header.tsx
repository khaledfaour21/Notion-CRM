
import React from 'react';
import { Share2Icon, StarIcon, MoreHorizontalIcon } from './icons';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-between px-8 py-3 border-b border-gray-800">
      <div>
        <h1 className="text-xl font-semibold text-white">Cold Outreach - LinkedIn - Email</h1>
      </div>
      <div className="flex items-center space-x-2">
        <span className="text-sm text-gray-400">Edited 1h ago</span>
        <button className="px-3 py-1 text-sm rounded hover:bg-gray-800 transition-colors">Share</button>
        <button className="p-2 rounded-full hover:bg-gray-800 transition-colors">
          <Share2Icon className="w-4 h-4" />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-800 transition-colors">
          <StarIcon className="w-4 h-4" />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-800 transition-colors">
          <MoreHorizontalIcon className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

export default Header;
