import React, { useState, useEffect, useRef } from 'react';
import {
  LeadsIcon,
  TableIcon,
  CalendarIcon,
  MessageSquareIcon,
  CheckSquareIcon,
  FileTextIcon,
  PenSquareIcon,
  LayoutGridIcon,
  Share2Icon,
  FilterIcon,
  SortIcon,
  SearchIcon,
  MoreHorizontalIcon,
  ChevronDownIcon,
  TrendingUpIcon,
  ChevronsUpDownIcon,
} from './icons';

interface SubHeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

const SubHeader: React.FC<SubHeaderProps> = ({ activeView, setActiveView }) => {
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(event.target as Node)) {
        setIsMoreMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const isMessagesView = activeView === 'All Messages';

  const navItems = [
    { text: 'All Leads', icon: <TableIcon className="w-4 h-4" /> },
    { text: 'Follow-ups', icon: <FileTextIcon className="w-4 h-4" /> },
    { text: 'Pipeline by Status', icon: <LayoutGridIcon className="w-4 h-4" /> },
    { text: 'Calendar', icon: <CalendarIcon className="w-4 h-4" /> },
    { text: 'At a glance', icon: <FileTextIcon className="w-4 h-4" /> },
    { text: 'All Messages', icon: <MessageSquareIcon className="w-4 h-4" /> },
    { text: 'Tasks Board', icon: <CheckSquareIcon className="w-4 h-4" /> },
    { text: 'All Tasks', icon: <TableIcon className="w-4 h-4" /> },
    { text: 'Quick Export', icon: <Share2Icon className="w-4 h-4" /> },
    { text: 'Lead Info Form', icon: <FileTextIcon className="w-4 h-4" /> },
    { text: 'Msg Form', icon: <PenSquareIcon className="w-4 h-4" /> },
    { text: 'Analytics', icon: <TrendingUpIcon className="w-4 h-4" /> },
  ];
  
  const VISIBLE_TABS = 4;
  const visibleItems = navItems.slice(0, VISIBLE_TABS);
  const hiddenItems = navItems.slice(VISIBLE_TABS);

  return (
    <div>
      <div className="flex items-center space-x-2 mb-4">
        {isMessagesView ? (
          <MessageSquareIcon className="w-6 h-6 text-blue-500" />
        ) : (
          <LeadsIcon className="w-6 h-6 text-red-500" />
        )}
        <h2 className="text-2xl font-bold text-white">
          {isMessagesView ? 'Lead Messages' : 'Leads'}
        </h2>
      </div>
      <div className="flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center space-x-1 pb-px">
            <>
              {visibleItems.map((item) => (
                <NavItem
                  key={item.text}
                  icon={item.icon}
                  text={item.text}
                  active={activeView === item.text}
                  onClick={() => setActiveView(item.text)}
                />
              ))}
              {hiddenItems.length > 0 && (
                <div className="relative flex-shrink-0" ref={moreMenuRef}>
                  <button
                    className="flex items-center space-x-1.5 text-sm text-gray-300 px-3 py-1.5 bg-[#2F2F2F] border border-gray-700 rounded-md hover:bg-gray-700/50 transition-colors"
                    onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                  >
                    <span>{hiddenItems.length} more...</span>
                    <ChevronsUpDownIcon className="w-3 h-3 text-gray-400" />
                  </button>

                  {isMoreMenuOpen && (
                    <div className="absolute top-full mt-2 w-60 bg-[#282828] border border-gray-700 rounded-md shadow-lg z-20 p-2">
                      {hiddenItems.map((item) => (
                        <div
                          key={item.text}
                          className="flex items-center space-x-3 p-2 text-sm text-gray-300 hover:bg-gray-700/50 rounded-md cursor-pointer"
                          onClick={() => {
                            setActiveView(item.text);
                            setIsMoreMenuOpen(false);
                          }}
                        >
                          {item.icon}
                          <span>{item.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
        </div>
        {!isMessagesView && (
             <div className="flex items-center space-x-2 flex-shrink-0">
                <ToolbarButton icon={<FilterIcon className="w-4 h-4" />} />
                <ToolbarButton icon={<SortIcon className="w-4 h-4" />} />
                <ToolbarButton icon={<SearchIcon className="w-4 h-4" />} />
                <ToolbarButton icon={<MoreHorizontalIcon className="w-4 h-4" />} />
                <div className="flex items-center ml-2">
                    <button className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-l-md text-sm font-medium transition-colors">
                        New
                    </button>
                    <div className="h-full border-l border-blue-500">
                        <button className="bg-blue-600 hover:bg-blue-700 text-white p-1.5 rounded-r-md transition-colors h-full">
                            <ChevronDownIcon className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

interface ToolbarButtonProps {
    icon: React.ReactNode;
    text?: string;
}

const ToolbarButton: React.FC<ToolbarButtonProps> = ({ icon, text }) => (
    <button className="flex items-center space-x-2 px-2 py-1 text-gray-300 rounded hover:bg-gray-700 transition-colors">
        {icon}
        {text && <span className="text-sm">{text}</span>}
    </button>
);

interface NavItemProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, active, onClick }) => {
  const baseClasses = "flex items-center space-x-2 px-3 py-2 text-sm rounded-t-md cursor-pointer transition-colors flex-shrink-0";
  // The active tab in the screenshot doesn't have a blue border, so I'm removing it.
  const activeClasses = "bg-[#2F2F2F] text-white";
  const inactiveClasses = "text-gray-400 hover:bg-gray-800/50";

  return (
    <div
      className={`${baseClasses} ${active ? activeClasses : inactiveClasses}`}
      onClick={onClick}
    >
      {icon}
      <span>{text}</span>
    </div>
  );
};

export default SubHeader;