import React from 'react';
import { Lead } from '../types';
import { 
    ChevronsLeftRightIcon, Maximize2Icon, Share2Icon, StarIcon, MoreHorizontalIcon,
    SparklesIcon, BuildingIcon, HashIcon, MessageSquareIcon, CalendarIcon, LinkIcon,
    FileTextIcon, TrendingUpIcon, TargetIcon, TagIcon, CheckSquareIcon, PlusIcon, InfoIcon, LeadsIcon,
} from './icons';

interface LeadDetailDrawerProps {
    lead: Lead | null;
    isOpen: boolean;
    onClose: () => void;
    onUpdateLead: (lead: Lead) => void;
}

const LeadDetailDrawer: React.FC<LeadDetailDrawerProps> = ({ lead, isOpen, onClose, onUpdateLead }) => {
    
    const drawerClasses = `absolute top-0 right-0 h-full w-[500px] bg-[#1E1E1E] border-l border-gray-800 flex flex-col transform transition-transform duration-300 ease-in-out z-20 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`;

    if (!lead) {
        return <aside className={drawerClasses}></aside>;
    }
    
    const properties = [
        { icon: <SparklesIcon className="w-4 h-4 text-gray-400"/>, label: "AI Export", value: <input type="checkbox" checked={lead.aiExport} className="form-checkbox h-4 w-4 bg-gray-700 border-gray-600 rounded text-blue-500 focus:ring-blue-500" onChange={e => onUpdateLead({...lead, aiExport: e.target.checked})} /> },
        { icon: <BuildingIcon className="w-4 h-4 text-gray-400"/>, label: "Company", value: lead.company || 'Empty' },
        { icon: <HashIcon className="w-4 h-4 text-gray-400"/>, label: "Contact Channel", value: <span className="px-2 py-0.5 text-xs rounded bg-[#373737] border border-gray-600">{lead.contactChannel}</span> },
        { icon: <MessageSquareIcon className="w-4 h-4 text-gray-400"/>, label: "Conversation ...", value: "Empty" },
        { icon: <CalendarIcon className="w-4 h-4 text-gray-400"/>, label: "Last Contact D...", value: lead.lastContactDate ? new Date(lead.lastContactDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric'}) : "Empty" },
        { icon: <LinkIcon className="w-4 h-4 text-gray-400"/>, label: "Linkedin", value: lead.linkedinUrl || "Empty" },
        { icon: <FileTextIcon className="w-4 h-4 text-gray-400"/>, label: "Messages", value: <div className="flex flex-col">{(lead.messages || '').split('\n').map((msg, i) => <span key={i} className="hover:bg-gray-700 px-1 rounded cursor-pointer">{msg || 'New page'}</span>)}</div> },
        { icon: <TrendingUpIcon className="w-4 h-4 text-gray-400"/>, label: "Next Follow-up...", value: "Empty" },
        { icon: <TargetIcon className="w-4 h-4 text-gray-400"/>, label: "Next Step (inline)", value: "Empty" },
        { icon: <StarIcon className="w-4 h-4 text-gray-400"/>, label: "Priority", value: "Empty" },
        { icon: <LeadsIcon className="w-4 h-4 text-gray-400"/>, label: "Role/Title", value: "Empty" },
        { icon: <HashIcon className="w-4 h-4 text-gray-400"/>, label: "Status", value: "Empty" },
        { icon: <TagIcon className="w-4 h-4 text-gray-400"/>, label: "Tags", value: "Empty" },
        { icon: <CheckSquareIcon className="w-4 h-4 text-gray-400"/>, label: "Tasks", value: lead.tasks || "Empty" },
    ];

    return (
        <aside className={`${drawerClasses} overflow-y-auto`}>
            {/* Drawer Header */}
            <div className="flex items-center justify-between p-2 border-b border-gray-800 text-gray-400 sticky top-0 bg-[#1E1E1E] z-10">
                <div className="flex items-center space-x-2">
                    <button onClick={onClose} className="p-1 rounded hover:bg-gray-800"><ChevronsLeftRightIcon className="w-4 h-4" /></button>
                    <button className="p-1 rounded hover:bg-gray-800"><Maximize2Icon className="w-4 h-4" /></button>
                </div>
                <div className="flex items-center space-x-1">
                    <button className="px-2 py-1 text-sm rounded hover:bg-gray-800">Share</button>
                    <button className="p-1 rounded hover:bg-gray-800"><StarIcon className="w-4 h-4" /></button>
                    <button className="p-1 rounded hover:bg-gray-800"><MoreHorizontalIcon className="w-4 h-4" /></button>
                </div>
            </div>

            <div className="flex-grow p-4">
                {/* Lead Name */}
                <div className="mb-6">
                    <h2 className="text-3xl font-bold text-white">{lead.name}</h2>
                </div>

                {/* Properties List */}
                <div className="space-y-1 text-sm">
                    {properties.map(prop => (
                        <div key={prop.label} className="flex items-start group hover:bg-gray-800/50 rounded p-1">
                            <div className="flex items-center w-40 flex-shrink-0 text-gray-400">
                                {prop.icon}
                                <span className="ml-2">{prop.label}</span>
                                <InfoIcon className="w-3 h-3 ml-auto text-gray-600" />
                            </div>
                            <div className="ml-4 text-white font-medium break-words w-full">
                                {prop.value}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Add a property button */}
                <div className="mt-2">
                    <button className="flex items-center space-x-2 text-gray-400 hover:bg-gray-800 p-1 rounded w-full text-left text-sm">
                        <PlusIcon className="w-4 h-4" />
                        <span>Add a property</span>
                    </button>
                </div>
                
                <div className="border-b border-gray-700 my-6"></div>

                {/* Comments */}
                <div>
                    <p className="text-sm text-gray-400 mb-2">Comments</p>
                    <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">F</div>
                        <input type="text" placeholder="Add a comment..." className="bg-transparent w-full focus:outline-none text-sm" />
                    </div>
                </div>
            </div>
            
            {/* Footer text */}
            <div className="p-4 mt-auto text-xs text-gray-500 border-t border-gray-800">
                Press Enter to continue with an empty page, or <a href="#" className="underline hover:text-gray-400">create a template</a>.
            </div>
        </aside>
    );
}

export default LeadDetailDrawer;