import React from 'react';
import { Lead, Status } from '../types';
import { PIPELINE_STATUS_CONFIG } from '../constants';
import { PlusIcon } from './icons';

interface PipelineViewProps {
  leads: Lead[];
  setLeads: React.Dispatch<React.SetStateAction<Lead[]>>;
}

const LeadCard: React.FC<{ lead: Lead }> = ({ lead }) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('leadId', lead.id.toString());
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="bg-[#2F2F2F] p-3 rounded-md border border-gray-700 cursor-grab active:cursor-grabbing shadow-sm"
    >
      <p className="font-medium text-white">{lead.name || 'New page'}</p>
      {lead.company && <p className="text-sm text-gray-400">{lead.company}</p>}
    </div>
  );
};

const PipelineView: React.FC<PipelineViewProps> = ({ leads, setLeads }) => {
    const handleDrop = (newStatus: Status, e: React.DragEvent<HTMLDivElement>) => {
        const leadId = parseInt(e.dataTransfer.getData('leadId'), 10);
        if (!leadId) return;

        setLeads(prevLeads =>
            prevLeads.map(lead =>
                lead.id === leadId ? { ...lead, status: newStatus } : lead
            )
        );
    };

    return (
        <div className="flex space-x-4 overflow-x-auto pb-4 h-full">
            {/* FIX: Cast Object.values(Status) to Status[] to ensure type safety when iterating and accessing PIPELINE_STATUS_CONFIG. */}
            {(Object.values(Status) as Status[]).map(status => {
                const config = PIPELINE_STATUS_CONFIG[status];
                const filteredLeads = leads.filter(l => l.status === status);
                
                return (
                    <div
                        key={status}
                        className="flex-shrink-0 w-72 flex flex-col"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => handleDrop(status, e)}
                    >
                        <div className="flex items-center space-x-2 p-2">
                            {config.icon}
                            <span className="font-medium text-white">{status}</span>
                            <span className="text-sm text-gray-400">{filteredLeads.length}</span>
                        </div>
                        <div className={`p-2 space-y-3 rounded-lg ${config.color} flex-grow`}>
                            {filteredLeads.map(lead => <LeadCard key={lead.id} lead={lead} />)}
                            <button className="flex items-center space-x-2 p-2 w-full rounded text-gray-400 hover:bg-gray-700/50 transition-colors">
                                <PlusIcon className="w-4 h-4" />
                                <span>New page</span>
                            </button>
                        </div>
                    </div>
                )
            })}
        </div>
    );
}

export default PipelineView;